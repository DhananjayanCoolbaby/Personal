import { Injectable, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
    providedIn: 'root'
})

export class EmployeeService {
    
    uri = 'http://localhost:64262';
    constructor(private http: HttpClient, private router: Router) {
    }
    public addEmployee(empdetails) {
        this.http.post(`${this.uri}/api/Employees`, empdetails)
            .subscribe(res => this.router.navigate(['view']));
    }

    public updateEmployee(empiID,empdetails){
        this.http.put(`${this.uri}/api/Employees`, empdetails)
        .subscribe(res => this.router.navigate(['view']));
    }
    
   
}