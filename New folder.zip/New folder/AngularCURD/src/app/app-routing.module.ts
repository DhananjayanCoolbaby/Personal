import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {EmployeeViewComponent} from './employee-view/employee-view.component';
import {EmployeeAddComponent} from './employee-add/employee-add.component';

const routes: Routes = [
    { path: '', redirectTo: '/view', pathMatch: 'full' },
    {
        path: 'view',
        component: EmployeeViewComponent
    },
    {
        path: 'view/create',
        component: EmployeeAddComponent
    },
    {
        path: 'view/create/:empId',
        component: EmployeeAddComponent
    },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
