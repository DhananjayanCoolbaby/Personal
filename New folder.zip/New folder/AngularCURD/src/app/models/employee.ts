export class Employee {
  dob: string = '';
  name: String = '';
  dept: string = '';
  gender: string = '';
  adtype: string = '';
  addr: string='';
}
