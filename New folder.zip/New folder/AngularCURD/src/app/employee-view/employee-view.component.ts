import { Component, OnInit } from '@angular/core';
import { Employee } from '../models/employee';
import { Observable } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { CustomerRemove } from '../customer.actions';
import { HttpClient } from '@angular/common/http';
import { Router ,ActivatedRoute} from '@angular/router';
@Component({
  selector: 'employee-view',
  templateUrl: './employee-view.component.html',
  styleUrls: ['./employee-view.component.css']
})
export class EmployeeViewComponent implements OnInit {
  uri = 'http://localhost:64262';
  public employees: any = [];
  public empIdFromParams: string = '';
  constructor(private store: Store<{ employees: Employee[] }>, private http: HttpClient, public router: Router,private acRoute: ActivatedRoute) {
    // this.store.pipe(select((state: any) => state.employees.employeeData)).subscribe((employeeData) => {
    // this.employees = employeeData;
  }
  public getEmployeeDetails() {
    this.http.get(`${this.uri}/api/Employees`)
      .subscribe(res => {
        if (res) {
          this.employees = res;
          this.employees.map((emp, ind) => {
            this.employees[ind].gender = (emp.gender == 1) ? 'Male' : 'Female';
            this.employees[ind].addr = emp.userAddress[0].addresslin1 + emp.userAddress[0].addresslin2;
          })

        }
      });
  }
  public deleteEmployeeDetails(empID) {  
    this.http.delete(`${this.uri}/api/Employees/`+empID)
      .subscribe(res => {
        this.getEmployeeDetails();
      })
  }
  public removeEmployee(empID) {
    let confirmMsg = confirm("Do you want delete this record");
    if (confirmMsg == true) {
    this.deleteEmployeeDetails(empID);
    }
  }
  public editEmployee(empId) {
    this.router.navigate(['view/create', empId])
  }
  ngOnInit() {
    this.getEmployeeDetails();
    
  }
}
