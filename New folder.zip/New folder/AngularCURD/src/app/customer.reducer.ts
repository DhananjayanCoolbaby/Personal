import {ActionEx, CustomerActionTypes} from './customer.actions';

const initialState = {
  employeeData: [],
  selected: null,
  action: null,
  done: false,
  error: null
};

export function CustomerReducer(state = initialState, action: ActionEx) {
  switch (action.type) {
    case CustomerActionTypes.Add:
    return { 
      ...state,
      employeeData: [...state.employeeData, action.payload]
  }

    case CustomerActionTypes.Remove:
      return [
        ...state.employeeData.slice(0, action.payload),
        ...state.employeeData.slice(action.payload + 1)
      ];
    default:
      return state;
  }
}
