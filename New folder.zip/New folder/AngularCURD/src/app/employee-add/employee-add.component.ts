import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { EmployeeService } from '../employee.service';
import { Employee } from '../models/employee';
import { Observable } from 'rxjs';
import { CustomerAdd } from '../customer.actions';
import { Router,ActivatedRoute } from '@angular/router';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { FormGroup, Validators, FormBuilder, FormControl, FormArray, ValidatorFn, AbstractControl } from '@angular/forms';

@Component({
  selector: 'employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {
  uri = 'http://localhost:64262';
  public addEmployeeGroup: FormGroup;
  public Statelist: any = [];
  public citylist: any = [];
  public empdetail: any = {};
  public empIdFromParams: string = '';
  public btnDetails: string = 'Submit';
  //public employees = "sfdsf";
  employees: Employee = new Employee();
  constructor(private store: Store<{ employees: Employee[] }>, 
    private router: Router, 
    public _formBuilder: FormBuilder, 
    public _employeeService: EmployeeService, 
    private http: HttpClient,
    private acRoute: ActivatedRoute) 
    {
    this.addEmployeeForm();
    //this.employees = store.pipe(select('employees'));
    //   this.store.pipe(select((state: any) => state.employees.employeeData)).subscribe((employeeData) => {
    //     this.employees = employeeData;
    //  });
  }
  public addEmployeeForm() {
    this.addEmployeeGroup = this._formBuilder.group({
      empname: [''],
      empdob: [''],
      dept: [''],
      gender: [''],
      adtype: [''],
      state: [''],
      city: [''],
      addr1: [],
      addr2: []
    })
  }
  public AddEmployee(empDetails) {
    if(this.btnDetails!="Update")
    {
    let addData = {
      "EmpName": empDetails.empname,
      "EmpDOB": empDetails.empdob,
      "EmpDepartment": empDetails.dept,
      "Gender": empDetails.gender,
      "userAddress": [
        {
          "AddressTypeRefId": empDetails.adtype,
          "Addresslin1": empDetails.addr1,
          "Addresslin2": empDetails.addr2,
          "StateRefId": empDetails.state,
          "City": empDetails.city
        }
      ],
    }
    this._employeeService.addEmployee(addData);
  }
  else{
    let empID=this.acRoute.snapshot.params['empId'];
    let updateDate={
      "EmpName": empDetails.empname,
      "EmpDOB": empDetails.empdob,
      "EmpDepartment": empDetails.dept,
      "Gender": empDetails.gender,
      "userAddress": [
        {
          "AddressTypeRefId": empDetails.adtype,
          "Addresslin1": empDetails.addr1,
          "Addresslin2": empDetails.addr2,
          "StateRefId": empDetails.state,
          "City": empDetails.city
        }
      ],
    }
    this._employeeService.updateEmployee(empID,updateDate);
  }
    //const employee = new Employee();
    // [1,3].map((v) => {

    // })
    // let data = this.employees.map((velue,key) => {
    //   alert(velue);
    // })
    //   this.employees['name'] = this.employees.name; 
    //  this.employees['addr'] = this.employees.adtype; 
    // this.store.dispatch(new CustomerAdd(this.employees));
  }
  public getStatelist() {
    this.http.get(`${this.uri}/api/States`)
      .subscribe(res => {
        this.Statelist = res;       
      });
  }
  public getCitylist() {
    this.http.get(`${this.uri}/api/Cities`)
      .subscribe(res => {
        this.citylist = res;        
      });
  }
  public getEmpDetails() {
    this.empIdFromParams = this.acRoute.snapshot.params['empId'];
    this.http.get(`${this.uri}/api/Employees/`+this.empIdFromParams)
      .subscribe(res => {
        this.empdetail = res;
        this.addEmployeeGroup.controls.empname.patchValue(this.empdetail.empName);
        //const apiDate: string = new Date(this.empdetail.empDOB).toUTCString();
        const bDate: Date = new Date('13/12/2019');
        bDate.toISOString().substring(0, 10);
        this.addEmployeeGroup.controls.empdob.patchValue(bDate);
        this.addEmployeeGroup.controls.dept.patchValue(this.empdetail.empDepartment);
        this.addEmployeeGroup.controls.adtype.patchValue(this.empdetail.adtype)
        this.addEmployeeGroup.controls.gender.patchValue(this.empdetail.gender)
    });
    if(this.empIdFromParams) {
      this.btnDetails = "Update";
    }
  }
  ngOnInit() {
    this.getEmpDetails();
    this.getStatelist();
    this.getCitylist();
  }
}
